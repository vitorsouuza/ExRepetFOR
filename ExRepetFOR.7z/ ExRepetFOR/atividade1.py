contador = 0
for n in range(1,101):
    if n %2 == 0:
        contador=contador+1
        print(n)
print(contador)